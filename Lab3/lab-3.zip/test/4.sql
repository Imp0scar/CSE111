.headers on
SELECT s_name
FROM Supplier
WHERE s_acctbal > 8000;