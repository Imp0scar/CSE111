.headers on
SELECT p.p_name AS part
FROM lineitem l
JOIN part p ON p.p_partkey = l.l_partkey
WHERE l.l_extendedprice * (1 - l.l_discount) = 
(
    SELECT MAX(l2.l_extendedprice * (1 - l2.l_discount))
    FROM lineitem l2
    WHERE l2.l_shipdate > '1994-10-6'
)
AND l.l_shipdate > '1994-10-6';
