.headers on
-- SELECT O.o_orderpriority AS priority,
-- count(*) AS item_cnt
-- FROM lineitem L
-- JOIN orders O ON O.o_orderkey = L.l_orderkey
-- WHERE strftime('%Y',O.o_orderdate) = '1998'
-- AND L.l_receiptdate < L.l_commitdate
-- GROUP BY O.o_orderpriority;

SELECT O.o_orderpriority AS priority, 
       COUNT(*) AS item_cnt
FROM Orders O
JOIN Lineitem L ON O.o_orderkey = L.l_orderkey
WHERE strftime('%Y', O.o_orderdate) = '1998'
AND L.l_receiptdate < L.l_commitdate
GROUP BY O.o_orderpriority
ORDER BY O.o_orderpriority;
