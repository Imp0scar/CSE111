.headers on
SELECT p.p_mfgr AS manufacturer
FROM part p
JOIN partsupp ps ON p.p_partkey = ps.ps_partkey
WHERE ps.ps_suppkey = '000000084'
AND ps.ps_availqty = (SELECT MIN(ps2.ps_availqty)
                      FROM partsupp ps2
                      WHERE ps2.ps_suppkey = '000000084');

