.headers on
SELECT s.s_name AS supplier, p.p_size AS part_size, MAX(ps.ps_supplycost) AS max_cost
FROM part p
JOIN partsupp ps ON p.p_partkey = ps.ps_partkey
JOIN supplier s ON ps.ps_suppkey = s.s_suppkey
JOIN nation n ON s.s_nationkey = n.n_nationkey
JOIN region r ON n.n_regionkey = r.r_regionkey
WHERE r.r_name = 'AFRICA' 
AND p.p_type LIKE '%NICKEL%'
GROUP BY p.p_size;
