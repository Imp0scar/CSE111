.headers on
WITH nations_to_america AS (
    SELECT
        s_nation.n_name AS supp_nation,
        cus_region.r_name AS cust_region,
        strftime('%Y', l.l_shipdate) AS year,
        SUM(l.l_extendedprice * (1 - l.l_discount)) AS revenue
    FROM
        lineitem l
    JOIN orders o ON o.o_orderkey = l.l_orderkey
    JOIN customer c ON c.c_custkey = o.o_custkey
    JOIN nation cus_nation ON cus_nation.n_nationkey = c.c_nationkey
    JOIN region cus_region ON cus_region.r_regionkey = cus_nation.n_regionkey
    JOIN partsupp ps ON l.l_partkey = ps.ps_partkey AND ps.ps_suppkey = l.l_suppkey
    JOIN supplier s ON s.s_suppkey = ps.ps_suppkey
    JOIN nation s_nation ON s_nation.n_nationkey = s.s_nationkey
    WHERE
        strftime('%Y', l.l_shipdate) = '1995'
    AND cus_region.r_name = 'ASIA'
    GROUP BY  
        s_nation.n_name, cus_region.r_name, year
)

SELECT
    revenue / (SELECT SUM(revenue) FROM nations_to_america) AS GERMANY_in_ASIA_in_1995
FROM 
    nations_to_america
WHERE
    supp_nation = 'GERMANY';
