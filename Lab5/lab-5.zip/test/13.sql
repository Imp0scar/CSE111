.headers on
SELECT sup_region.r_name AS supp_region, 
       cus_region.r_name AS cust_region, 
       strftime('%Y', l.l_shipdate) AS year, 
       SUM(l.l_extendedprice * (1 - l.l_discount)) AS revenue
FROM lineitem l
JOIN orders o ON o.o_orderkey = l.l_orderkey
JOIN customer c ON c.c_custkey = o.o_custkey
JOIN nation cus_nation ON cus_nation.n_nationkey = c.c_nationkey
JOIN region cus_region ON cus_region.r_regionkey = cus_nation.n_regionkey
JOIN partsupp ps ON l.l_partkey = ps.ps_partkey AND ps.ps_suppkey = l.l_suppkey
JOIN supplier s ON s.s_suppkey = ps.ps_suppkey
JOIN nation sup_nation ON sup_nation.n_nationkey = s.s_nationkey
JOIN region sup_region ON sup_region.r_regionkey = sup_nation.n_regionkey
WHERE strftime('%Y', l.l_shipdate) IN ('1996', '1997')
GROUP BY sup_region.r_name, cus_region.r_name, year;
