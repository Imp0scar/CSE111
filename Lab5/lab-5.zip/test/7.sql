.headers on
SELECT part
FROM
(
    SELECT p.p_name AS part, ps.ps_supplycost * ps.ps_availqty AS total_value, n.n_name AS country
    FROM part p
    JOIN partsupp ps ON p.p_partkey = ps.ps_partkey
    JOIN supplier s ON ps.ps_suppkey = s.s_suppkey
    JOIN nation n ON s.s_nationkey = n.n_nationkey
    WHERE n.n_name = 'ARGENTINA'
    ORDER BY total_value DESC
    LIMIT (
        SELECT COUNT(*) * 0.05
        FROM part p2
        JOIN partsupp ps2 ON p2.p_partkey = ps2.ps_partkey
        JOIN supplier s2 ON ps2.ps_suppkey = s2.s_suppkey
        JOIN nation n2 ON s2.s_nationkey = n2.n_nationkey
        WHERE n2.n_name = 'ARGENTINA'
    )
)
ORDER BY part;
