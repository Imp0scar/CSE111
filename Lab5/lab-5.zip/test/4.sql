.headers on
SELECT COUNT(DISTINCT ps.ps_suppkey) AS supp_cnt
FROM part p
JOIN partsupp ps ON p.p_partkey = ps.ps_partkey
WHERE p.p_type LIKE '%BRUSHED%' 
AND p.p_size IN (10, 20, 30, 40);
