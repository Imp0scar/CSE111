.headers on
SELECT N.n_name AS country, 
       COUNT(DISTINCT C.c_custkey) AS cust_cnt, 
       COUNT(DISTINCT S.s_suppkey) AS supp_cnt
FROM Nation N
JOIN Region R ON N.n_regionkey = R.r_regionkey
JOIN Customer C ON N.n_nationkey = C.c_nationkey
JOIN Supplier S ON N.n_nationkey = S.s_nationkey
WHERE R.r_name = 'ASIA'
GROUP BY N.n_name;
