.headers on
SELECT r.r_name AS region, COUNT(DISTINCT s.s_suppkey) AS supp_cnt
FROM supplier s
JOIN nation n ON s.s_nationkey = n.n_nationkey
JOIN region r ON n.n_regionkey = r.r_regionkey
JOIN (
    SELECT r2.r_name, AVG(s2.s_acctbal) AS avgbal
    FROM supplier s2
    JOIN nation n2 ON s2.s_nationkey = n2.n_nationkey
    JOIN region r2 ON n2.n_regionkey = r2.r_regionkey
    GROUP BY r2.r_name
) AS region_avg ON r.r_name = region_avg.r_name
WHERE s.s_acctbal > region_avg.avgbal
GROUP BY r.r_name;
